---
name: Atmospheric HUD Editorial
colors:
  surface: '#fbf8ff'
  surface-dim: '#d9d8ed'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2ff'
  surface-container: '#eeecff'
  surface-container-high: '#e8e6fb'
  surface-container-highest: '#e2e0f6'
  on-surface: '#191a29'
  on-surface-variant: '#464555'
  inverse-surface: '#2e2f3f'
  inverse-on-surface: '#f1efff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4c42e9'
  primary: '#493ee5'
  on-primary: '#ffffff'
  primary-container: '#635bff'
  on-primary-container: '#fefaff'
  inverse-primary: '#c3c0ff'
  secondary: '#00668a'
  on-secondary: '#ffffff'
  secondary-container: '#40c2fd'
  on-secondary-container: '#004d6a'
  tertiary: '#815100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffaf9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#321ed2'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#fbf8ff'
  on-background: '#191a29'
  surface-variant: '#e2e0f6'
  lavender-tint: '#F2EFFF'
  surface-porcelain: '#FAF9FF'
  graphite-text: '#1A1A24'
  mist-subtle: '#E8E5F7'
typography:
  display-hero:
    fontFamily: Manrope
    fontSize: 4.5rem
    fontWeight: '600'
    lineHeight: '1.05'
    letterSpacing: -0.035em
  headline-lg:
    fontFamily: Manrope
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.45'
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system reimagines high-precision atmospheric observation through an ultra-clean, architectural editorial aesthetic. Moving away from dark cosmic voids into luminous daylight, the visual identity pairs the analytical rigor of meteorological instrumentation with the crisp clarity of Swiss layout systems and cool lavender tonality.

The emotional tone is calm, luminous, authoritative, and frictionless. Surfaces are bathed in pale lavender mists, porcelain planes, and crisp graphite lines, punctuated by high-tension electric iris accents. Interfaces avoid heavy skeuomorphism in favor of subtle layered translucency, structured spatial typography, and hairline architectural boundaries.

## Colors

The palette transitions to a high-contrast, light-mode system anchored by luminous lavender atmospheres and high-density graphite typography.

- **Primary (`#635BFF` - Electric Iris):** Directs primary focus, critical interaction states, active telemetry plots, and operational triggers.
- **Lavender Tint (`#F2EFFF`):** The signature atmospheric tint applied to key canvas layers, module headers, and elevated tonal containers.
- **Secondary (`#38BDF8` - Cyan Barometric):** Expresses kinetic atmospheric layers, precipitation vectors, and active stream flows.
- **Tertiary (`#F59E0B` - Daylight Amber):** Serves warning thresholds, solar UV metrics, and high-intensity weather states.
- **Neutral & Structural Foundations:**
  - **Base Canvas:** `#FAF9FF` (Porcelain mist).
  - **Surface Default:** `#FFFFFF` (Pure white architectural cards).
  - **Surface Container:** `#F2EFFF` (Cool tinted atmospheric substrate).
  - **Typography (On-Surface):** `#1A1A24` (High-contrast graphite ink providing WCAG AAA readability).
  - **Borders & Outlines:** `#E0DDF0` and `#68687A` for razor-sharp micro-rulers.

## Typography

Typography establishes an editorial structural balance between the geometric modernism of Manrope and the analytical neutrality of Inter:

- **Manrope** anchors all display titles, primary atmospheric values, telemetry hero metrics, and section headings. It introduces contemporary refinement with open counters and balanced geometry.
- **Inter** handles high-density tabular records, sensor outputs, form components, and body narratives, maintaining uncompromising clarity across light lavender backgrounds.
- **Telemetry Readouts:** Numerical sensor values (e.g., temperatures, barometric pressures) are typeset in Manrope with tabular figures (`tnum`) enabled, paired with superscript degree markers or uppercase unit labels set in Inter `label-sm`.

## Layout & Spacing

The spatial engine utilizes an editorial 12-column layout emphasizing structured margins, disciplined rhythm, and generous whitespace.

- **Desktop (1280px+):** Fixed analytical rail (72px collapsed or 240px expanded) alongside a 12-column dynamic workplane. Outer canvas margins sit at 2rem with 1.5rem gutters. Modules snap to 3, 4, 6, or 12 column blocks.
- **Tablet (768px - 1279px):** Adapts to an 8-column layout with 1.5rem margins. Primary telemetry blocks collapse to 4 columns each, creating a paired 2x2 grid.
- **Mobile (< 768px):** Reflows into a single-column stack with 1rem margins and 1rem gutters. Dense metric matrices switch into horizontal scroll tracks with snap alignments.
- **Component Padding Scale:** Controlled exclusively through `space-xs` (0.25rem) to `space-xl` (2.5rem), maintaining optical alignment across nested containers.

## Elevation & Depth

Visual hierarchy abandons heavy dark drop shadows in favor of ambient lavender tinting, razor-sharp hairline borders, and diffused porcelain layering.

1. **Substrate (Layer 0):** Background porcelain base (`#FAF9FF`) layered with subtle atmospheric gradient washes of `#F2EFFF`.
2. **Surface Plane (Layer 1):** Solid white (`#FFFFFF`) or tinted porcelain (`#F2EFFF`) panels bordered with crisp 1px lines (`#E0DDF0`). No heavy blur; surfaces are pristine and architectural.
3. **Floating Modules (Layer 2):** Modals, dropdowns, and flyout HUDs utilize subtle, hyper-diffused ambient lavender shadows: `0 8px 30px -4px rgba(99, 91, 255, 0.08), 0 2px 6px -1px rgba(26, 26, 36, 0.04)`, enclosed with a sharp `#D4CFF5` border.
4. **Active Rim Accents:** Focused or selected cards exhibit a hairline 1px border shift to `#635BFF` with an exterior soft focus glow (`0 0 0 3px rgba(99, 91, 255, 0.12)`).

## Shapes

The design system adopts roundedness level 1 (Soft), producing technical, architectural corners reminiscent of precision optics and print design:

- **Base Corner Radius:** 0.25rem (4px) for micro-elements, inputs, dropdown items, and table cells.
- **Standard Cards & Containers:** `rounded-lg` (0.5rem / 8px) for modular analytical cards and HUD groupings.
- **Overlays & Dialogs:** `rounded-xl` (0.75rem / 12px) for high-level modals and floating toolbars.
- **Functional Pills:** 9999px is reserved strictly for status badges, tags, and categorical metric chips.

## Components

### Buttons & Operational Controls
- **Primary Action:** Solid `#635BFF` fill with crisp `#FFFFFF` typography. Features `0.25rem` radius, 0.5rem vertical and 1.25rem horizontal padding. Hover shifts to `#4F46E5` with an understated ambient lavender glow.
- **Secondary (Lavender Mist):** Background of `#F2EFFF`, text in `#635BFF`, 1px border in `#D4CFF5`. Hover darkens substrate to `#E8E3FF`.
- **Tertiary / Outline:** Transparent background with 1px border (`#DCD9EE`), graphite text (`#1A1A24`). Hover fills with `#FAF9FF`.
- **Icon Buttons:** 36x36px square with `0.25rem` radius, bordered in hairline `#E0DDF0`.

### Cards & Analytical Panels
- **Anatomy:** `#FFFFFF` background, 1px border in `#E0DDF0`, `rounded-lg` (0.5rem) corners, and internal padding of `space-lg`.
- **Telemetry Card Variant:** Header strip tinted in `#F2EFFF` holding uppercase `label-md` trackers in `#68687A`, separating title logic from numeric metric displays.
- **Hover State:** Border shifts to `#635BFF`, accompanied by subtle lavender tint accentuation.

### Input Fields & Search Bars
- **Surface:** Recessed porcelain (`#FFFFFF`) with 1px border in `#DCD9EE` and `0.25rem` radius.
- **Typography:** Placeholder text set to `#8A879E` in `body-md`; active value in `#1A1A24`.
- **Focus State:** 1px border in `#635BFF` with `0 0 0 3px rgba(99, 91, 255, 0.12)` halo.

### Chips & Badges
- **Status Pills:** Fully rounded (9999px) capsules with `0.25rem` vertical and `0.75rem` horizontal padding.
- **Lavender Neutral:** Background `#F2EFFF`, text `#635BFF`, border `#E0DDF0`.
- **Alert / Condition Variant:** Solar Amber tinted base (`rgba(245, 158, 11, 0.12)`) with deep amber text (`#9A3412`) for storm and UV alerts.

### Checkboxes & Radio Controls
- **Form Factor:** 16x16px control with `0.25rem` corners for checkboxes; circular for radios. 
- **Inactive:** `#FFFFFF` fill with 1.5px border in `#C8C5DC`.
- **Active / Checked:** Filled with `#635BFF` featuring a crisp white geometric check or inner dot.

### Telemetry HUD Gauges & Data Tables
- **Grid Dividers:** Hairline borders (`#EBE8F8`) between rows; zebra striping using alternating `#FFFFFF` and `#F8F7FD`.
- **Progress & Vector Gauges:** Track background set to `#F2EFFF`, active metric fill in `#635BFF` or `#38BDF8`.